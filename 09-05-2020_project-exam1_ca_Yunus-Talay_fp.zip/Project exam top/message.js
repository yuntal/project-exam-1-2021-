function displayError(message = "Unknown error") {
    return `<div class="error">${message}</div>`;
}